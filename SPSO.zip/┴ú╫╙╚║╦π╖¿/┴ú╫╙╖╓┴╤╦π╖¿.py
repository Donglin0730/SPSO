#库的导入
import numpy as np
import random
import matplotlib.pyplot as plt
from CEC2022 import cec2022_func
import pandas as pd
import os

#待求解问题
def function(x):
    y = CEC.values(x)
    return y.ObjFunc

fx_n = 1 #公式
dim=10
CEC = cec2022_func(func_num = fx_n)
rangepop=[-100,100]    #取值范围
N=100   #种群数量
iterators = 1000    #迭代次数
w=0.9   #惯性因子
#两个加速系数
c1=np.full(N * 2,2.0)
c2=np.full(N * 2,2.0)
#x用于存储种群个体位置信息，v用于存储种群个体移动速度，fitness用于存储个体适应度值
x=np.zeros((N * 2,dim))
v = np.zeros((N * 2, dim))
fitness = np.zeros(N * 2)
NoUpdateTime = np.zeros(N * 2)

#对种群个体、移动速度进行初始化，计算初始适应度值
for j in range(N):
    x[j] = np.random.uniform(low=-100, high=100,size=(1, dim))
    v[j] = np.zeros((1,dim))
    c1[j] = c1[j]*0.7
    c2[j] = c2[j]*1.3
for j in range(N):
    x[j+N] = -x[j].copy()
    v[j+N] = v[j].copy()
    c1[j+N] = c1[j+N]*1.3
    c2[j+N] = c2[j+N]*0.7
fitness = function(np.transpose(x[0:2*N, :]))

#Xgbest,fgbest分别表示种群历史最优个体和适应度值
Xgbest,fgbest=x[fitness.argmin()].copy(),fitness.min()
#Xpbest,fpbest分别存储个体历史最优位置和适应度值
Xpbest,fpbest=x.copy(),fitness.copy()  
#bestfitness用于存储每次迭代时的种群历史最优适应度值
bestfitness=np.zeros(iterators)
#开始迭代
for t in range(0,iterators):
    w = 1 - (t+1)/iterators
    print("generation:",t)
    for i in range(N):
        r1 = np.random.rand()
        r2 = np.random.rand()
        #根据粒子分裂策略计算粒子移动速度
        v[i]=w*v[i]+c1[i]*r1*(Xpbest[i]-x[i])+c2[i]*r2*(Xgbest-x[i])
        #计算新的位置
        dis = np.linalg.norm(x[i]-Xgbest)
        x[i]=x[i]+v[i]+1/2/(dis**2*fitness[i])
        #确保更新后的位置在取值范围内
        for j in range(dim):    
            if x[i][j]<rangepop[0]:
                x[i][j] = rangepop[0]
            if x[i][j]>rangepop[1]:
                x[i][j] = rangepop[1]
    #计算适应度值
    fitness = function(np.transpose(x[0:2*N, :]))
    for i in range(N):
        #更新个体历史最优适应度值
        if fitness[i]<fpbest[i]:
            fpbest[i]=fitness[i]
            Xpbest[i]=x[i].copy()
    #更新种群历史最优适应度值
    if fpbest.min()<fgbest:
        fgbest=fpbest.min()
        Xgbest=Xpbest[fpbest.argmin()].copy()
    bestfitness[t]=fgbest
    print("the best fitness is:",bestfitness[t])
    for m in range(2*N):
        for n in range(m+1,2*N):
            if fitness[n]<fitness[m]:
                v[n],v[m] = v[m].copy(),v[n].copy()
                x[n],x[m] = x[m].copy(),x[n].copy()
                c1[n],c1[m] = c1[m],c1[n]
                c2[n],c2[m] = c2[m],c2[n]
                fitness[n],fitness[m] = fitness[m],fitness[n]
                fpbest[n],fpbest[m] = fpbest[m],fpbest[n]
                Xpbest[n],Xpbest[m] = Xpbest[m].copy(),Xpbest[n].copy()
    # 采用粒子分裂策略，生成各粒子对应的对称子粒子速度和位置信息
    for j in range(N):
        x[j+N] = -x[j].copy()
        v[j+N] = v[j].copy()
    fitness = function(np.transpose(x[0:2*N, :]))
    # 学习加速度改进策略
    for j in range(N):
        c1[j] = 2.0*N/((1+N)*N/2)*(j)
        c2[j] = 2.0-c1[j]
        c1[j+N] = c2[j]
        c2[j+N] = c1[j]
